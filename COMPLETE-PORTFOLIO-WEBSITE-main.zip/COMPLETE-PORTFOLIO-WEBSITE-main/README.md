# COMPLETE-PORTFOLIO-WEBSITE

COMPLETE PORTFOLIO WEBSITE &lt; HTML > { CSS } ( JavaScript )

The fruit of patience is sweet. Let's [check the webpage.](https://shu-vro.github.io/COMPLETE-PORTFOLIO-WEBSITE/)

_DISCLAIMER: YOU SHOULD USE VITE FOR DEVELOPMENT AND PRODUCTION. to deploy using github pages, visit [vite](https://vitejs.dev/guide/static-deploy#github-pages)_

However, if you do not use vite, you cannot access the mapbox from now (not a big deal). Website will still work, but not with the fancy map. A default placeholder image would be shown.

<!-- NO MORE FREE API KEYS 🍌 -->
